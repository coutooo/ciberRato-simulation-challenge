python mainRob.py "$@"
